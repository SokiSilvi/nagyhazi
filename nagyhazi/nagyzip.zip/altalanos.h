#pragma once

#include <string>


void fajlkiolvas(std::string fajlnev);