#pragma once

#include <string>




class Pont {

	int x, y;

public:

	Pont(int x, int y) : x(x), y(y) {}

};

class Mezo : public Pont {

	std::string id;
	bool stone, real, side, free;

public:

	Mezo(int x, int y, std::string id, bool stone, bool real, bool side, bool free) : Pont(x, y), id(id), stone(stone), real(real), side(side), free(free) {}
	void stoned() { stone = true; free = false; }
	void catted() { free = false; }
	void setfree() { free = true; }
	std::string drawline1();
	std::string drawline2();

};

class Middle : public Mezo {

	Mezo& topleft, topright, top, bottomleft, bottomright, bottom, left, right;

};

class TopLeft : public Mezo { 

	Mezo& bottomright, bottom, right;

};

class TopRight : public Mezo {

	Mezo& topleft, top, left;

};

class Bottomleft : public Mezo {

	Mezo& topright, top, right;

};

class BottomRight : public Mezo { 

	Mezo& topleft, top, left;

};

class Top : public Mezo { 

	Mezo& bottomleft, bottomright, bottom, left, right;

};

class Bottom : public Mezo {

	Mezo& topleft, topright, top, left, right;

};

class Right : public Mezo {

	Mezo& topleft, top, bottomleft, bottom, left;

};

class Left : public Mezo {

	Mezo& topright, top, bottomright, bottom, right;

};








class User {

	std::string email;
	std::string nickname;
	std::string password;
	int games;

public:

	User(std::string email, std::string nickname, std::string password) : email(email), nickname(nickname), password(password), games(0) {}
	void setjatszott(int jatszottt) { games = jatszottt; }
	void setpass(std::string pass) { password = pass; }
	virtual void lep() {}

};

class Man : public User {

public:

	Man(std::string email, std::string nickname, std::string password) : User(email, nickname, password) {}
	void lep();

};

class Cat : public User {

	Mezo where;

public:

	Cat(std::string email, std::string nickname, std::string password, Mezo where) : User(email, nickname, password), where(where) {}
	void lep();
	void drawline();

};





