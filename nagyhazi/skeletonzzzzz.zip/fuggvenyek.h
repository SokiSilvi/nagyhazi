#pragma once
#include "classes.h"

User regisztracio();    
User bejelentkezes();  

void palya();
